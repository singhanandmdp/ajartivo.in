from rembg import remove
from PIL import Image

input_path = r"C:\Users\Admin\Music\My Website\Aj Artivo\tools\Aj Pixel Cut\input.jpg"
output_path = r"C:\Users\Admin\Music\My Website\Aj Artivo\tools\Aj Pixel Cut\output.png"

input_image = Image.open(input_path)
output = remove(input_image)

output.save(output_path)

print("Done! Background removed ✅")