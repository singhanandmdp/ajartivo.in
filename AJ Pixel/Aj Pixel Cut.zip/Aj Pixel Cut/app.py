from flask import Flask, request, send_file, jsonify
from flask_cors import CORS
from rembg import remove, new_session
from PIL import Image
import io

app = Flask(__name__)
CORS(app)

# ✅ Best balanced model (no harsh edges, no color change)
session = new_session("u2net")

@app.route('/')
def home():
    return "AJ Pixel Cut API Running 🚀"


@app.route('/remove-bg', methods=['POST'])
def remove_bg():
    try:
        # ❌ No file
        if 'image' not in request.files:
            return jsonify({"error": "No file uploaded"}), 400

        file = request.files['image']

        # ✅ Load image (NO processing)
        input_image = Image.open(file.stream).convert("RGBA")

        # ✅ Remove background (NO color change)
        output = remove(
            input_image,
            session=session,
            alpha_matting=True,
            alpha_matting_foreground_threshold=240,
            alpha_matting_background_threshold=10,
            alpha_matting_erode_size=5
        )

        # 💾 Save to memory
        img_io = io.BytesIO()
        output.save(img_io, format="PNG")
        img_io.seek(0)

        return send_file(
            img_io,
            mimetype='image/png',
            as_attachment=True,
            download_name='ajartivo.png'
        )

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True, port=5000)