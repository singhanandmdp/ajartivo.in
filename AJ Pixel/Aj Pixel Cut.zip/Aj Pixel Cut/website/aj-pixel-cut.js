const uploadBox = document.getElementById("uploadBox");
const fileInput = document.getElementById("fileInput");
const reuploadBtn = document.getElementById("reuploadBtn");

const beforeImg = document.getElementById("beforeImg");
const afterCanvas = document.getElementById("afterCanvas");
const afterCtx = afterCanvas.getContext("2d");
const brushPreview = document.getElementById("brushPreview");

const resultWrapper = document.getElementById("resultWrapper");
const downloadBtn = document.getElementById("downloadBtn");
const actionRow = document.querySelector(".action-row");
const scan = document.getElementById("scan");
const imgWrap = document.querySelector(".img-wrap");
const beforeStage = document.getElementById("beforeStage");
const afterStage = document.getElementById("afterStage");

const colorCircles = document.querySelectorAll(".color-circle[data-color]");
const colorPicker = document.getElementById("colorPicker");
const gradientPreset = document.getElementById("gradientPreset");
const gradientStart = document.getElementById("gradientStart");
const gradientEnd = document.getElementById("gradientEnd");
const gradientAngle = document.getElementById("gradientAngle");

const refineBtn = document.getElementById("refineBtn");
const resizeBtn = document.getElementById("resizeBtn");
const outlineBtn = document.getElementById("outlineBtn");
const eraseModeBtn = document.getElementById("eraseModeBtn");
const restoreModeBtn = document.getElementById("restoreModeBtn");
const undoBtn = document.getElementById("undoBtn");
const redoBtn = document.getElementById("redoBtn");

const refinePanel = document.getElementById("refinePanel");
const resizePanel = document.getElementById("resizePanel");
const outlinePanel = document.getElementById("outlinePanel");
const gradientPanel = document.getElementById("gradientPanel");

const brushSizeInput = document.getElementById("brushSize");
const brushHardnessInput = document.getElementById("brushHardness");
const resizeScaleInput = document.getElementById("resizeScale");
const outlineSizeInput = document.getElementById("outlineSize");
const outlineColorInput = document.getElementById("outlineColor");

let baseCanvas = document.createElement("canvas");
let baseCtx = baseCanvas.getContext("2d");
let maskCanvas = document.createElement("canvas");
let maskCtx = maskCanvas.getContext("2d");

let selectedBackground = { type: "transparent", value: "transparent" };
let selectedOutline = { enabled: false, size: 8, color: "#ffffff" };
let resizeScale = 1;
let brushSize = Number(brushSizeInput.value);
let brushHardness = Number(brushHardnessInput.value);
let refineMode = false;
let refineAction = "erase";
let isPainting = false;
let currentImageUrl = "";
let undoStack = [];
let redoStack = [];
let beforeZoom = 1;
let beforePanX = 0;
let beforePanY = 0;
let sharedZoom = 1;
let isBeforePanning = false;
let panStartX = 0;
let panStartY = 0;
let panOriginX = 0;
let panOriginY = 0;
let spacePressed = false;
let hardnessLabelTimer = null;
let activeUploadController = null;
let uploadToken = 0;

function setButtonActive(button, active){
    button.classList.toggle("active", active);
}

function closePanels(){
    [refinePanel, resizePanel, outlinePanel, gradientPanel].forEach(panel=>{
        panel.classList.remove("active");
    });
    [refineBtn, resizeBtn, outlineBtn, gradientPreset].forEach(btn=>{
        btn.classList.remove("active");
    });
}

function setActiveBackgroundCircle(color){
    colorCircles.forEach(circle=>circle.classList.remove("active"));
    colorCircles.forEach(circle=>{
        if(circle.getAttribute("data-color") === color){
            circle.classList.add("active");
        }
    });
}

function applyBackground(choice){
    if(choice === "transparent"){
        selectedBackground = { type: "transparent", value: "transparent" };
        gradientPreset.classList.remove("active");
        setActiveBackgroundCircle("transparent");
    }else if(choice === "gradient"){
        selectedBackground = { type: "gradient" };
        gradientPreset.classList.add("active");
    }else{
        selectedBackground = { type: "solid", value: choice };
        gradientPreset.classList.remove("active");
        setActiveBackgroundCircle(choice);
    }
    renderCanvas();
}

function applyStageTransform(stage, zoom, panX, panY){
    stage.style.setProperty("--preview-zoom", zoom);
    stage.style.setProperty("--preview-pan-x", `${panX}px`);
    stage.style.setProperty("--preview-pan-y", `${panY}px`);
}

function applyPreviewTransforms(){
    if(beforeStage){
        applyStageTransform(beforeStage, sharedZoom, beforePanX, beforePanY);
    }
    if(afterStage){
        applyStageTransform(afterStage, sharedZoom, beforePanX, beforePanY);
    }
}

function clampStagePan(stage, zoom, panState){
    if(!stage){
        return;
    }

    const width = stage.clientWidth || 0;
    const height = stage.clientHeight || 0;
    const maxX = Math.max(0, (zoom - 1) * width / 2);
    const maxY = Math.max(0, (zoom - 1) * height / 2);

    panState.x = Math.min(maxX, Math.max(-maxX, panState.x));
    panState.y = Math.min(maxY, Math.max(-maxY, panState.y));

    if(zoom <= 1){
        panState.x = 0;
        panState.y = 0;
    }

    return panState;
}

function setSharedZoom(nextZoom){
    sharedZoom = Math.min(5, Math.max(0.5, nextZoom));
    beforeZoom = sharedZoom;
    const clamped = clampStagePan(beforeStage, sharedZoom, { x: beforePanX, y: beforePanY });
    beforePanX = clamped.x;
    beforePanY = clamped.y;
    applyPreviewTransforms();
}

function initMask(){
    maskCanvas.width = baseCanvas.width;
    maskCanvas.height = baseCanvas.height;
    maskCtx.clearRect(0, 0, maskCanvas.width, maskCanvas.height);
    maskCtx.fillStyle = "white";
    maskCtx.fillRect(0, 0, maskCanvas.width, maskCanvas.height);
    undoStack = [maskCtx.getImageData(0, 0, maskCanvas.width, maskCanvas.height)];
    redoStack = [];
}

function snapshotMask(){
    return maskCtx.getImageData(0, 0, maskCanvas.width, maskCanvas.height);
}

function restoreMask(imageData){
    maskCtx.putImageData(imageData, 0, 0);
    renderCanvas();
}

function pushHistory(){
    undoStack.push(snapshotMask());
    if(undoStack.length > 30){
        undoStack.shift();
    }
    redoStack = [];
}

function undoMask(){
    if(undoStack.length <= 1){
        return;
    }
    redoStack.push(snapshotMask());
    undoStack.pop();
    restoreMask(undoStack[undoStack.length - 1]);
}

function redoMask(){
    if(!redoStack.length){
        return;
    }
    const state = redoStack.pop();
    undoStack.push(state);
    restoreMask(state);
}

function createMaskedForegroundCanvas(){
    const foregroundCanvas = document.createElement("canvas");
    foregroundCanvas.width = baseCanvas.width;
    foregroundCanvas.height = baseCanvas.height;
    const fgCtx = foregroundCanvas.getContext("2d");

    fgCtx.drawImage(baseCanvas, 0, 0);
    fgCtx.globalCompositeOperation = "destination-in";
    fgCtx.drawImage(maskCanvas, 0, 0);
    fgCtx.globalCompositeOperation = "source-over";

    return foregroundCanvas;
}

function createOutlineCanvas(foregroundCanvas, width, height){
    const outlineCanvas = document.createElement("canvas");
    outlineCanvas.width = width;
    outlineCanvas.height = height;
    const outlineCtx = outlineCanvas.getContext("2d");

    outlineCtx.filter = `blur(${selectedOutline.size}px)`;
    outlineCtx.drawImage(foregroundCanvas, 0, 0);
    outlineCtx.filter = "none";
    outlineCtx.globalCompositeOperation = "source-in";
    outlineCtx.fillStyle = selectedOutline.color;
    outlineCtx.fillRect(0, 0, width, height);

    return outlineCanvas;
}

function buildBackgroundFill(ctx, width, height){
    if(selectedBackground.type === "solid"){
        ctx.fillStyle = selectedBackground.value;
        ctx.fillRect(0, 0, width, height);
        return;
    }

    if(selectedBackground.type === "gradient"){
        const angle = Number(gradientAngle.value || 135) * Math.PI / 180;
        const x = Math.cos(angle);
        const y = Math.sin(angle);
        const gradient = ctx.createLinearGradient(
            width * (0.5 - x * 0.5),
            height * (0.5 - y * 0.5),
            width * (0.5 + x * 0.5),
            height * (0.5 + y * 0.5)
        );
        gradient.addColorStop(0, gradientStart.value);
        gradient.addColorStop(1, gradientEnd.value);
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, width, height);
    }
}

function renderCanvas(){
    if(!baseCanvas.width || !baseCanvas.height){
        return;
    }

    const displayWidth = baseCanvas.width;
    const displayHeight = baseCanvas.height;

    afterCanvas.width = displayWidth;
    afterCanvas.height = displayHeight;
    afterCanvas.style.width = "100%";
    afterCanvas.style.height = "auto";

    afterCtx.clearRect(0, 0, displayWidth, displayHeight);
    const foregroundCanvas = createMaskedForegroundCanvas();

    if(selectedOutline.enabled && selectedOutline.size > 0){
        const outlineCanvas = createOutlineCanvas(foregroundCanvas, displayWidth, displayHeight);
        afterCtx.drawImage(outlineCanvas, 0, 0);
    }

    afterCtx.drawImage(foregroundCanvas, 0, 0);

    if(selectedBackground.type === "transparent"){
        imgWrap.style.background = "transparent";
    }else if(selectedBackground.type === "solid"){
        imgWrap.style.background = selectedBackground.value;
    }else{
        imgWrap.style.background = `linear-gradient(${gradientAngle.value}deg, ${gradientStart.value}, ${gradientEnd.value})`;
    }

    applyPreviewTransforms();
}

function showBrushPreview(event){
    const rect = afterStage.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    brushPreview.style.display = "block";
    updateBrushPreviewVisual();
    brushPreview.style.left = `${x}px`;
    brushPreview.style.top = `${y}px`;
}

function updateBrushPreviewVisual(){
    const hardnessRatio = Math.min(100, Math.max(0, brushHardness)) / 100;
    const softEdge = Math.round((1 - hardnessRatio) * 56) + 10;
    const innerStop = Math.max(18, 100 - softEdge);
    const borderAlpha = 0.55 + (hardnessRatio * 0.4);
    const label = hardnessRatio < 0.33 ? "Soft" : hardnessRatio < 0.66 ? "Medium" : "Hard";

    brushPreview.style.width = `${brushSize}px`;
    brushPreview.style.height = `${brushSize}px`;
    brushPreview.style.background = `radial-gradient(circle at center,
        rgba(255,255,255,${0.22 + hardnessRatio * 0.18}) 0%,
        rgba(255,255,255,${0.18 + hardnessRatio * 0.22}) ${innerStop}%,
        rgba(255,255,255,0.02) 100%)`;
    brushPreview.style.borderColor = `rgba(255,255,255,${borderAlpha})`;
    brushPreview.dataset.hardnessLabel = `${label} ${Math.round(hardnessRatio * 100)}%`;
}

function showHardnessLabelTemporarily(){
    brushPreview.classList.add("show-hardness-label");
    window.clearTimeout(hardnessLabelTimer);
    hardnessLabelTimer = window.setTimeout(()=>{
        brushPreview.classList.remove("show-hardness-label");
    }, 700);
}

function showHardnessPreviewInCenter(){
    const rect = afterStage.getBoundingClientRect();
    brushPreview.style.display = "block";
    updateBrushPreviewVisual();
    brushPreview.classList.remove("show-hardness-label");
    brushPreview.style.left = `${rect.width / 2}px`;
    brushPreview.style.top = `${rect.height / 2}px`;
}

function playBrushHardnessPreview(){
    brushPreview.classList.remove("hardness-anim");
    void brushPreview.offsetWidth;
    brushPreview.classList.add("hardness-anim");
    window.clearTimeout(playBrushHardnessPreview._timer);
    playBrushHardnessPreview._timer = window.setTimeout(()=>{
        brushPreview.classList.remove("hardness-anim");
    }, 220);
}

function hideBrushPreview(){
    brushPreview.style.display = "none";
}

function canvasPoint(event){
    const rect = afterCanvas.getBoundingClientRect();
    return {
        x: ((event.clientX - rect.left) / rect.width) * afterCanvas.width,
        y: ((event.clientY - rect.top) / rect.height) * afterCanvas.height
    };
}

function createBrushStamp(radius){
    const diameter = Math.max(1, Math.ceil(radius * 2));
    const stamp = document.createElement("canvas");
    stamp.width = diameter;
    stamp.height = diameter;
    const stampCtx = stamp.getContext("2d");

    const hardness = (Math.min(100, Math.max(0, brushHardness)) / 100) * 0.75;
    const innerRadius = Math.max(0, radius * hardness);
    const outerRadius = radius;
    const center = diameter / 2;

    stampCtx.beginPath();
    stampCtx.arc(center, center, outerRadius, 0, Math.PI * 2);
    if(hardness >= 1){
        stampCtx.fillStyle = "rgba(255,255,255,1)";
        stampCtx.fill();
        return stamp;
    }

    const gradient = stampCtx.createRadialGradient(center, center, innerRadius, center, center, outerRadius);
    gradient.addColorStop(0, "rgba(255,255,255,1)");
    gradient.addColorStop(1, "rgba(255,255,255,0)");

    stampCtx.fillStyle = gradient;
    stampCtx.fill();

    return stamp;
}

function applyBrush(point){
    const rect = afterCanvas.getBoundingClientRect();
    const scale = rect.width / afterCanvas.width || 1;
    const brushRadius = brushSize / (2 * scale);
    const stamp = createBrushStamp(brushRadius);

    maskCtx.save();
    if(refineAction === "erase"){
        maskCtx.globalCompositeOperation = "destination-out";
    }else{
        maskCtx.globalCompositeOperation = "source-over";
    }
    maskCtx.drawImage(stamp, point.x - brushRadius, point.y - brushRadius);
    maskCtx.restore();
    renderCanvas();
}

async function handleFile(file){
    if(!file){
        return;
    }

    uploadToken += 1;
    const currentToken = uploadToken;
    if(activeUploadController){
        activeUploadController.abort();
    }
    activeUploadController = new AbortController();

    sharedZoom = 1;
    beforeZoom = 1;
    beforePanX = 0;
    beforePanY = 0;
    applyPreviewTransforms();

    beforeImg.src = URL.createObjectURL(file);
    uploadBox.style.display = "none";
    reuploadBtn.parentElement.style.display = "flex";
    resultWrapper.style.display = "flex";
    scan.style.display = "block";
    afterCanvas.style.display = "none";
    hideBrushPreview();
    actionRow.style.display = "none";

    const formData = new FormData();
    formData.append("image", file);

    try{
        const res = await fetch("http://127.0.0.1:5000/remove-bg", {
            method: "POST",
            body: formData,
            signal: activeUploadController.signal
        });

        if(currentToken !== uploadToken){
            return;
        }

        if(!res.ok){
            const text = await res.text();
            throw new Error(text || `Request failed (${res.status})`);
        }

        const blob = await res.blob();
        currentImageUrl = URL.createObjectURL(blob);

        const sourceImage = new Image();
        sourceImage.src = currentImageUrl;
        await sourceImage.decode();

        baseCanvas.width = sourceImage.naturalWidth;
        baseCanvas.height = sourceImage.naturalHeight;
        baseCtx.clearRect(0, 0, baseCanvas.width, baseCanvas.height);
        baseCtx.drawImage(sourceImage, 0, 0);
        initMask();

        scan.style.display = "none";
        afterCanvas.style.display = "block";
        actionRow.style.display = "flex";
        downloadBtn.style.display = "inline-block";
        renderCanvas();
    }catch(err){
        if(err.name === "AbortError"){
            return;
        }
        scan.style.display = "none";
        alert("Error: " + err.message);
    }
}

function downloadWithBackground(){
    if(!baseCanvas.width || !baseCanvas.height){
        return;
    }

    const outputCanvas = document.createElement("canvas");
    outputCanvas.width = Math.round(baseCanvas.width * resizeScale);
    outputCanvas.height = Math.round(baseCanvas.height * resizeScale);
    const ctx = outputCanvas.getContext("2d");

    buildBackgroundFill(ctx, outputCanvas.width, outputCanvas.height);

    const foregroundCanvas = createMaskedForegroundCanvas();

    if(selectedOutline.enabled && selectedOutline.size > 0){
        const outlineCanvas = createOutlineCanvas(foregroundCanvas, outputCanvas.width, outputCanvas.height);
        ctx.drawImage(outlineCanvas, 0, 0, outputCanvas.width, outputCanvas.height);
    }

    ctx.drawImage(foregroundCanvas, 0, 0, outputCanvas.width, outputCanvas.height);

    outputCanvas.toBlob((blob)=>{
        if(!blob){
            alert("Could not create download file.");
            return;
        }

        const url = URL.createObjectURL(blob);
        const tempLink = document.createElement("a");
        tempLink.href = url;
        tempLink.download = "ajartivo.png";
        tempLink.click();
        setTimeout(()=> URL.revokeObjectURL(url), 1000);
    }, "image/png");
}

/* EVENTS */
uploadBox.addEventListener("click", ()=> fileInput.click());
reuploadBtn.addEventListener("click", ()=>{
    fileInput.value = "";
    fileInput.click();
});
fileInput.addEventListener("change", ()=> handleFile(fileInput.files[0]));

uploadBox.addEventListener("dragover", (e)=> e.preventDefault());
uploadBox.addEventListener("drop", (e)=>{
    e.preventDefault();
    handleFile(e.dataTransfer.files[0]);
});

colorCircles.forEach(circle=>{
    circle.addEventListener("click", ()=>{
        applyBackground(circle.getAttribute("data-color"));
    });
});

colorPicker.addEventListener("input", ()=>{
    applyBackground(colorPicker.value);
});

gradientPreset.addEventListener("click", ()=>{
    applyBackground("gradient");
    setButtonActive(gradientPreset, true);
    gradientPanel.classList.toggle("active");
    refinePanel.classList.remove("active");
    resizePanel.classList.remove("active");
    outlinePanel.classList.remove("active");
    refineBtn.classList.remove("active");
    resizeBtn.classList.remove("active");
    outlineBtn.classList.remove("active");
});

gradientStart.addEventListener("input", ()=>{
    if(selectedBackground.type === "gradient"){
        renderCanvas();
    }
});

gradientEnd.addEventListener("input", ()=>{
    if(selectedBackground.type === "gradient"){
        renderCanvas();
    }
});

gradientAngle.addEventListener("input", ()=>{
    if(selectedBackground.type === "gradient"){
        renderCanvas();
    }
});

refineBtn.addEventListener("click", ()=>{
    refineMode = !refineMode;
    setButtonActive(refineBtn, refineMode);
    refinePanel.classList.toggle("active", refineMode);
    resizePanel.classList.remove("active");
    outlinePanel.classList.remove("active");
    gradientPanel.classList.remove("active");
    resizeBtn.classList.remove("active");
    outlineBtn.classList.remove("active");
    gradientPreset.classList.remove("active");
    if(!refineMode){
        hideBrushPreview();
    }
});

resizeBtn.addEventListener("click", ()=>{
    resizePanel.classList.toggle("active");
    resizeBtn.classList.toggle("active");
    refinePanel.classList.remove("active");
    outlinePanel.classList.remove("active");
    gradientPanel.classList.remove("active");
    refineBtn.classList.remove("active");
    outlineBtn.classList.remove("active");
    gradientPreset.classList.remove("active");
    hideBrushPreview();
});

outlineBtn.addEventListener("click", ()=>{
    selectedOutline.enabled = !selectedOutline.enabled;
    outlineBtn.classList.toggle("active", selectedOutline.enabled);
    outlinePanel.classList.toggle("active", selectedOutline.enabled);
    refinePanel.classList.remove("active");
    resizePanel.classList.remove("active");
    gradientPanel.classList.remove("active");
    refineBtn.classList.remove("active");
    resizeBtn.classList.remove("active");
    gradientPreset.classList.remove("active");
    renderCanvas();
});

eraseModeBtn.addEventListener("click", ()=>{
    refineAction = "erase";
    eraseModeBtn.classList.add("active");
    restoreModeBtn.classList.remove("active");
});

restoreModeBtn.addEventListener("click", ()=>{
    refineAction = "restore";
    restoreModeBtn.classList.add("active");
    eraseModeBtn.classList.remove("active");
});

undoBtn.addEventListener("click", undoMask);
redoBtn.addEventListener("click", redoMask);

brushSizeInput.addEventListener("input", ()=>{
    brushSize = Number(brushSizeInput.value);
    updateBrushPreviewVisual();
});

brushHardnessInput.addEventListener("input", ()=>{
    brushHardness = Number(brushHardnessInput.value);
    if(brushPreview.style.display === "block"){
        updateBrushPreviewVisual();
        showHardnessLabelTemporarily();
        playBrushHardnessPreview();
    }else{
        showHardnessPreviewInCenter();
        showHardnessLabelTemporarily();
        playBrushHardnessPreview();
    }
});

resizeScaleInput.addEventListener("input", ()=>{
    resizeScale = Number(resizeScaleInput.value) / 100;
    renderCanvas();
});

outlineSizeInput.addEventListener("input", ()=>{
    selectedOutline.size = Number(outlineSizeInput.value);
    renderCanvas();
});

outlineColorInput.addEventListener("input", ()=>{
    selectedOutline.color = outlineColorInput.value;
    renderCanvas();
});

document.querySelectorAll(".panel-close").forEach(button=>{
    button.addEventListener("click", ()=>{
        const panel = document.getElementById(button.dataset.panel);
        panel.classList.remove("active");
        if(button.dataset.panel === "refinePanel"){
            refineMode = false;
            refineBtn.classList.remove("active");
            hideBrushPreview();
        }
        if(button.dataset.panel === "resizePanel"){
            resizeBtn.classList.remove("active");
        }
        if(button.dataset.panel === "outlinePanel"){
            selectedOutline.enabled = false;
            outlineBtn.classList.remove("active");
            renderCanvas();
        }
        if(button.dataset.panel === "gradientPanel"){
            gradientPreset.classList.remove("active");
        }
    });
});

beforeStage.addEventListener("pointerdown", (e)=>{
    if(beforeZoom <= 1){
        return;
    }
    e.preventDefault();
    isBeforePanning = true;
    panStartX = e.clientX;
    panStartY = e.clientY;
    panOriginX = beforePanX;
    panOriginY = beforePanY;
    beforeStage.setPointerCapture(e.pointerId);
});

beforeStage.addEventListener("pointermove", (e)=>{
    if(!isBeforePanning){
        return;
    }

    e.preventDefault();
    beforePanX = panOriginX + (e.clientX - panStartX);
    beforePanY = panOriginY + (e.clientY - panStartY);
    const clamped = clampStagePan(beforeStage, beforeZoom, { x: beforePanX, y: beforePanY });
    beforePanX = clamped.x;
    beforePanY = clamped.y;
    applyPreviewTransforms();
});

beforeStage.addEventListener("pointerup", ()=>{
    isBeforePanning = false;
});

beforeStage.addEventListener("pointercancel", ()=>{
    isBeforePanning = false;
});

beforeStage.addEventListener("wheel", (e)=>{
    e.preventDefault();
    const delta = e.deltaY > 0 ? -0.1 : 0.1;
    setSharedZoom(sharedZoom + delta);
    const clamped = clampStagePan(beforeStage, sharedZoom, { x: beforePanX, y: beforePanY });
    beforePanX = clamped.x;
    beforePanY = clamped.y;
    applyPreviewTransforms();
}, { passive: false });

afterStage.addEventListener("wheel", (e)=>{
    e.preventDefault();
    const delta = e.deltaY > 0 ? -0.1 : 0.1;
    setSharedZoom(sharedZoom + delta);
}, { passive: false });

afterCanvas.addEventListener("pointerenter", (e)=>{
    if(refineMode){
        showBrushPreview(e);
    }
});

afterCanvas.addEventListener("pointermove", (e)=>{
    if(refineMode){
        showBrushPreview(e);
        if(isPainting){
            applyBrush(canvasPoint(e));
        }
    }
});

afterCanvas.addEventListener("pointerleave", ()=>{
    hideBrushPreview();
    isPainting = false;
});

window.addEventListener("keydown", (e)=>{
    if(e.code === "Space"){
        spacePressed = true;
        if(refineMode){
            afterCanvas.style.cursor = "grab";
        }
    }
});

window.addEventListener("keyup", (e)=>{
    if(e.code === "Space"){
        spacePressed = false;
        if(refineMode){
            afterCanvas.style.cursor = "default";
        }
    }
});

afterCanvas.addEventListener("pointerdown", (e)=>{
    if(!refineMode || !baseCanvas.width){
        return;
    }
    pushHistory();
    isPainting = true;
    afterCanvas.setPointerCapture(e.pointerId);
    applyBrush(canvasPoint(e));
});

afterCanvas.addEventListener("pointerup", ()=>{
    isPainting = false;
});

downloadBtn.addEventListener("click", (e)=>{
    e.preventDefault();
    downloadWithBackground();
});
